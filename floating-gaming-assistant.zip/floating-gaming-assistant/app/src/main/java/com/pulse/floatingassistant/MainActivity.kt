package com.pulse.floatingassistant

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var permissionStatus: TextView
    private lateinit var permissionButton: Button
    private lateinit var startButton: Button
    private lateinit var runningStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        permissionStatus = findViewById(R.id.permissionStatus)
        permissionButton = findViewById(R.id.permissionButton)
        startButton = findViewById(R.id.startButton)
        runningStatus = findViewById(R.id.runningStatus)

        findViewById<View>(R.id.settingsButton).setOnClickListener {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }

        permissionButton.setOnClickListener {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION).apply {
                data = Uri.parse("package:$packageName")
            })
        }
        startButton.setOnClickListener { startAssistant() }
        updatePermissionUi()

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 40)
        }
    }

    override fun onResume() {
        super.onResume()
        updatePermissionUi()
    }

    private fun updatePermissionUi() {
        val granted = Settings.canDrawOverlays(this)
        permissionStatus.text = if (granted) {
            "✓ صلاحية الظهور فوق التطبيقات مفعّلة"
        } else {
            "فعّل صلاحية الظهور فوق التطبيقات لعرض المقبض فوق الألعاب"
        }
        permissionButton.visibility = if (granted) View.GONE else View.VISIBLE
        startButton.isEnabled = granted
        runningStatus.text = if (granted) "المساعد جاهز للعمل" else "بانتظار الصلاحية"
    }

    private fun startAssistant() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "فعّل صلاحية الظهور فوق التطبيقات أولاً", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val intent = Intent(this, OverlayService::class.java)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
            runningStatus.text = getString(R.string.assistant_running)
        } catch (error: RuntimeException) {
            runningStatus.text = "تعذر تشغيل المساعد — تحقق من صلاحيات النظام"
            Toast.makeText(this, "تعذر تشغيل اللوحة العائمة", Toast.LENGTH_LONG).show()
        }
    }
}
