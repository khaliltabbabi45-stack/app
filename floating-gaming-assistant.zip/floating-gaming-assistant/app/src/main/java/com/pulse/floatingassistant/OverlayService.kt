package com.pulse.floatingassistant

import android.app.ActivityManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.pm.ServiceInfo
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import java.io.BufferedReader
import java.io.FileReader
import java.util.Locale

class OverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private lateinit var handleView: View
    private lateinit var panelView: View
    private lateinit var scrimView: View
    private val mainHandler = Handler(Looper.getMainLooper())
    private var panelVisible = false
    private var previousCpu: CpuSnapshot? = null

    private val updateTask = object : Runnable {
        override fun run() {
            updateMetrics()
            mainHandler.postDelayed(this, 1000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        createNotificationChannel()
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(NOTIFICATION_ID, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(NOTIFICATION_ID, buildNotification())
            }
        } catch (_: Exception) {
            stopSelf()
            return
        }
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        handleView = LayoutInflater.from(this).inflate(R.layout.overlay_handle, null)
        panelView = LayoutInflater.from(this).inflate(R.layout.overlay_panel, null)
        scrimView = View(this).apply { setBackgroundColor(0x00000000) }
        addHandle()
        wirePanelActions()
        mainHandler.post(updateTask)
    }

    private fun addHandle() {
        handleView.setOnTouchListener(object : View.OnTouchListener {
            private var downX = 0f
            private var downY = 0f
            private var moved = false
            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { downX = event.rawX; downY = event.rawY; moved = false }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = event.rawX - downX
                        val dy = event.rawY - downY
                        if (kotlin.math.abs(dx) > 8 || kotlin.math.abs(dy) > 8) moved = true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (moved) {
                            val params = v.layoutParams as WindowManager.LayoutParams
                            params.y = event.rawY.toInt() - v.height / 2
                            windowManager.updateViewLayout(v, params)
                        } else if (panelVisible) hidePanel() else showPanel()
                    }
                }
                return true
            }
        })
        try {
            windowManager.addView(handleView, handleParams())
        } catch (_: Exception) {
            stopSelf()
        }
    }

    private fun wirePanelActions() {
        panelView.findViewById<ImageButton>(R.id.closeButton).setOnClickListener { hidePanel() }
        scrimView.setOnClickListener { hidePanel() }
        panelView.findViewById<View>(R.id.optimizeButton).setOnClickListener {
            // Safe operation: ask this process to release trim-able memory; never kill other apps.
            onTrimMemory(TRIM_MEMORY_RUNNING_LOW)
            Runtime.getRuntime().gc()
            Toast.makeText(this, "تم طلب تحسين آمن لذاكرة المساعد", Toast.LENGTH_SHORT).show()
        }
        panelView.findViewById<View>(R.id.settingsShortcut).setOnClickListener {
            startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        panelView.findViewById<View>(R.id.batteryShortcut).setOnClickListener {
            startActivity(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    private fun showPanel() {
        if (panelVisible) return
        try {
            windowManager.addView(scrimView, scrimParams())
            windowManager.addView(panelView, panelParams())
            panelVisible = true
        } catch (_: Exception) {
            safeRemove(panelView)
            safeRemove(scrimView)
            Toast.makeText(this, "تعذر فتح لوحة اللعب على هذا الجهاز", Toast.LENGTH_SHORT).show()
        }
    }

    private fun hidePanel() {
        if (!panelVisible) return
        panelVisible = false
        safeRemove(panelView)
        safeRemove(scrimView)
    }

    private fun updateMetrics() {
        if (!::panelView.isInitialized) return
        try {
            val memory = getSystemService(ACTIVITY_SERVICE) as ActivityManager
            val info = ActivityManager.MemoryInfo()
            memory.getMemoryInfo(info)
            val usedMb = (info.totalMem - info.availMem) / (1024 * 1024)
            val totalMb = info.totalMem / (1024 * 1024)
            panelView.findViewById<TextView>(R.id.ramValue).text = "${usedMb}M/${totalMb}M"

            val current = readCpuSnapshot()
            val cpuText = previousCpu?.let { old ->
                val totalDelta = current.total - old.total
                val idleDelta = current.idle - old.idle
                if (totalDelta > 0) String.format(Locale.US, "%.0f%%", (100.0 * (totalDelta - idleDelta) / totalDelta)) else "--"
            } ?: "--"
            previousCpu = current
            panelView.findViewById<TextView>(R.id.cpuValue).text = cpuText

            val battery = registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val level = battery?.getIntExtra("level", -1) ?: -1
            val scale = battery?.getIntExtra("scale", 100) ?: 100
            val percent = if (level >= 0) (level * 100 / scale) else -1
            panelView.findViewById<TextView>(R.id.batteryValue).text = if (percent >= 0) "$percent%" else "--"
        } catch (_: Exception) {
            // Metrics are optional; never let a read failure kill the overlay service.
        }
    }

    private fun readCpuSnapshot(): CpuSnapshot {
        BufferedReader(FileReader("/proc/stat")).use { reader ->
            val fields = reader.readLine().trim().split(Regex("\\s+"))
            val values = fields.drop(1).take(8).map { it.toLongOrNull() ?: 0L }
            val total = values.sum()
            val idle = (values.getOrNull(3) ?: 0L) + (values.getOrNull(4) ?: 0L)
            return CpuSnapshot(total, idle)
        }
    }

    private fun handleParams() = WindowManager.LayoutParams(
        dp(34), dp(88), overlayType(),
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.START or Gravity.CENTER_VERTICAL; x = 0 }

    private fun panelParams() = WindowManager.LayoutParams(
        dp(300), WindowManager.LayoutParams.WRAP_CONTENT, overlayType(),
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.START or Gravity.CENTER_VERTICAL; x = 0 }

    private fun scrimParams() = WindowManager.LayoutParams(
        WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, overlayType(),
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
        PixelFormat.TRANSLUCENT
    )

    private fun overlayType() = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    private fun safeRemove(view: View) { try { if (view.isAttachedToWindow) windowManager.removeView(view) } catch (_: Exception) {} }

    override fun onDestroy() {
        mainHandler.removeCallbacksAndMessages(null)
        hidePanel()
        if (::handleView.isInitialized) safeRemove(handleView)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_NOT_STICKY

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "Gaming Assistant", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        return builder.setContentTitle("Pulse Gaming Assistant")
            .setContentText("المساعد يعمل فوق الألعاب")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setOngoing(true)
            .build()
    }

    private data class CpuSnapshot(val total: Long, val idle: Long)

    companion object {
        private const val CHANNEL_ID = "pulse_gaming_assistant"
        private const val NOTIFICATION_ID = 1042
    }
}
