# The app uses Android framework APIs only; no custom keep rules are required.
