# Pulse Floating Gaming Assistant

تطبيق Android Native خفيف بلغة Kotlin، متوافق مع Android 10 (API 29) وما بعده.

## المزايا
- مقبض جانبي Overlay صغير وقابل للسحب.
- لوحة جانبية تظهر فوق الألعاب ويمكن إغلاقها بالنقر خارجها أو زر الإغلاق.
- قراءة RAM الكلية/المستخدمة، CPU utilization من `/proc/stat`، ونسبة البطارية.
- زر تحسين آمن يطلب من نظام Android تخفيف الذاكرة القابلة للاسترجاع للتطبيق نفسه فقط؛ لا يغلق تطبيقات أخرى بالقوة.
- اختصارات إعدادات الجهاز والبطارية.
- خدمة Foreground مع إشعار دائم لاستقرار الـ overlay.

## الهيكل
- `app/src/main/java/.../MainActivity.kt`: الشاشة الرئيسية وطلب صلاحية `SYSTEM_ALERT_WINDOW`.
- `app/src/main/java/.../OverlayService.kt`: WindowManager، المقبض، اللوحة، القياسات والتحديث كل ثانية.
- `app/src/main/res/layout/overlay_panel.xml`: واجهة اللوحة.
- `app/src/main/res/layout/overlay_handle.xml`: المقبض الجانبي.
- `app/src/main/AndroidManifest.xml`: الصلاحيات وتعريف الخدمة.

## البناء
يتطلب Android Studio حديثاً (يفضل Hedgehog أو أحدث) أو Android SDK مع JDK 17. افتح مجلد المشروع في Android Studio، اترك Gradle Sync يكتمل، ثم اختر **Build > Make Project**.

من الطرفية، إذا كان Gradle مثبتاً:

```bash
gradle :app:assembleDebug
```

النتيجة:

```text
app/build/outputs/apk/debug/app-debug.apk
```

للتثبيت عبر ADB:

```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

افتح التطبيق، فعّل "الظهور فوق التطبيقات"، ثم اضغط "تشغيل المساعد". على Android 13+ اسمح أيضاً بإشعارات الخدمة.

## ملاحظات مهمة
تطبيقات Android العادية لا تملك صلاحية موثوقة لقتل تطبيقات أخرى أو تنظيف RAM العامة؛ لذلك لا يستخدم المشروع API مخفية أو أساليب عدوانية. مراقبة CPU هنا قراءة تقريبية للنظام، بينما RAM مأخوذة من `ActivityManager.MemoryInfo`.
